Linguavision Bulk Import Guide

1. Place static images (.jpg, .png) in the 'images' folder.
2. Place GIFs in the 'animations' folder.
3. Place pronunciation audio (.mp3) in the 'audio' folder.
4. Make sure filenames match EXACTLY with the Excel sheet.