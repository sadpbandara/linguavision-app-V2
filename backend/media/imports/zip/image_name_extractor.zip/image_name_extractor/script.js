const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');
const emptyState = document.getElementById('emptyState');
const countEl = document.getElementById('count');
const totalSizeEl = document.getElementById('totalSize');
const copyBtn = document.getElementById('copyBtn');
const downloadBtn = document.getElementById('downloadBtn');
const clearBtn = document.getElementById('clearBtn');
const statusEl = document.getElementById('status');

let images = [];

function isImage(file) {
  return file.type.startsWith('image/') ||
    /\.(jpe?g|png|gif|webp|bmp|tiff?|svg|avif|heic)$/i.test(file.name);
}

function addFiles(fileCollection) {
  const incoming = Array.from(fileCollection || []);
  const accepted = incoming.filter(isImage);
  const rejected = incoming.length - accepted.length;

  // Keep the selected order and allow identically named files from different folders.
  images.push(...accepted);
  render();

  let message = accepted.length + ' image(s) එකතු කරන ලදී.';
  if (rejected) message += ' Image නොවන ' + rejected + ' file(s) මඟහැරුණි.';
  statusEl.textContent = message;
}

function getNames() {
  const withExtension = document.querySelector('input[name="nameMode"]:checked').value === 'with';
  return images.map(file => {
    if (withExtension) return file.name;
    return file.name.replace(/\.[^.]+$/, '');
  });
}

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function render() {
  const names = getNames();
  fileList.replaceChildren();
  names.forEach(name => {
    const li = document.createElement('li');
    li.textContent = name;
    fileList.appendChild(li);
  });

  countEl.textContent = images.length.toLocaleString();
  totalSizeEl.textContent = formatSize(images.reduce((sum, file) => sum + file.size, 0));
  emptyState.hidden = images.length > 0;
  fileList.hidden = images.length === 0;
  copyBtn.disabled = downloadBtn.disabled = clearBtn.disabled = images.length === 0;
}

function downloadText() {
  const content = getNames().join('\n') + '\n';
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'image_names.txt';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  statusEl.textContent = 'image_names.txt download කිරීම ආරම්භ විය.';
}

dropZone.addEventListener('dragover', event => {
  event.preventDefault();
  dropZone.classList.add('dragover');
});
dropZone.addEventListener('dragleave', event => {
  if (!dropZone.contains(event.relatedTarget)) dropZone.classList.remove('dragover');
});
dropZone.addEventListener('drop', event => {
  event.preventDefault();
  dropZone.classList.remove('dragover');
  addFiles(event.dataTransfer.files);
});
dropZone.addEventListener('keydown', event => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    fileInput.click();
  }
});
fileInput.addEventListener('change', event => {
  addFiles(event.target.files);
  fileInput.value = ''; // allows selecting the same files again
});
document.querySelectorAll('input[name="nameMode"]').forEach(radio => {
  radio.addEventListener('change', render);
});
copyBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(getNames().join('\n'));
    statusEl.textContent = 'නම් Clipboard එකට Copy කරන ලදී.';
  } catch {
    statusEl.textContent = 'Copy කිරීමට නොහැකි විය. Download TXT භාවිත කරන්න.';
  }
});
downloadBtn.addEventListener('click', downloadText);
clearBtn.addEventListener('click', () => {
  images = [];
  render();
  statusEl.textContent = 'සියලු පින්තූර ඉවත් කරන ලදී.';
});
render();
