Image Name Extractor
====================

භාවිතය:
1. ZIP file එක Extract කරන්න.
2. index.html file එක Chrome / Edge browser එකෙන් open කරන්න.
3. පින්තූර 500ක් හෝ ඊට වැඩි ප්‍රමාණයක් එකවර drop zone එකට drag & drop කරන්න.
4. Extension නැති නම් හෝ extension සමඟ නම් යන්න තෝරන්න.
5. Download TXT ඔබන්න.

මෙය browser එක තුළම ක්‍රියා කරයි. පින්තූර කිසිවක් server එකකට upload නොවේ.
TXT file එකේ එක් පින්තූරයක නම එක් පේළියකට ලැබේ.
